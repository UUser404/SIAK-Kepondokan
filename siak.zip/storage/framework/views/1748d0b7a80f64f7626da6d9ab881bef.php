


<?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'layouts.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> Dashboard <?php $__env->endSlot(); ?>

    <?php
    $hour = now()->hour;
    if ($hour < 11) { $greeting='Selamat Pagi' ; $emoji='🌅' ; }
        elseif ($hour < 15) { $greeting='Selamat Siang' ; $emoji='☀️' ; }
        elseif ($hour < 18) { $greeting='Selamat Sore' ; $emoji='🌤️' ; }
        else { $greeting='Selamat Malam' ; $emoji='🌙' ; }
        ?>

        <div class="mb-8">
        <h1 class="text-2xl font-semibold hidden md:block" style="color: var(--siakad-dark);">
            <?php echo e($greeting); ?>, <?php echo e(explode(' ', Auth::user()->name)[0]); ?>! <?php echo e($emoji); ?>

        </h1>
        <p class="text-sm mt-1 hidden md:block" style="color: var(--siakad-secondary);">
            Ringkasan data dan aktivitas sistem hari ini
        </p>
        </div>

        <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <?php $__currentLoopData = [
            ['icon'=>'M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z', 'value'=>$totalSantri, 'label'=>'Santri Aktif'],
            ['icon'=>'M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z', 'value'=>$totalPendidik, 'label'=>'Tenaga Pendidik'],
            ['icon'=>'M18 9v3m0 0v3m0-3h3m-3 0h-3m-2.25-4.125a3.375 3.375 0 11-6.75 0 3.375 3.375 0 016.75 0zM4 19.235v-.11a6.375 6.375 0 0112.75 0v.109A12.318 12.318 0 0110.374 21a12.318 12.318 0 01-6.374-1.766z', 'value'=>$totalPpdb, 'label'=>'Menunggu PPDB'],
            ['icon'=>'M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z', 'value'=>$totalSurat, 'label'=>'Surat Bulan Ini'],
            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card-saas p-5">
                <div class="flex items-center gap-3">
                    <div class="w-11 h-11 rounded-xl flex items-center justify-center"
                        style="background-color: rgba(35,76,106,0.1);">
                        <svg class="w-5 h-5" style="color: var(--siakad-primary);"
                            fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="<?php echo e($stat['icon']); ?>" />
                        </svg>
                    </div>
                    <div>
                        <p class="text-2xl font-bold" style="color: var(--siakad-dark);"><?php echo e($stat['value']); ?></p>
                        <p class="text-xs" style="color: var(--siakad-secondary);"><?php echo e($stat['label']); ?></p>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="card-saas overflow-hidden">
            <div class="px-5 py-4 flex items-center justify-between"
                style="border-bottom: 1px solid var(--border-color);">
                <h3 class="font-semibold text-sm" style="color: var(--siakad-dark);">Pendaftar PPDB Terbaru</h3>
                <a href="<?php echo e(route('admin.ppdb.index')); ?>" class="text-xs font-medium transition-colors"
                    style="color: var(--siakad-primary);">Lihat semua →</a>
            </div>
            <div class="divide-y" style="border-color: var(--border-color);">
                <?php $__empty_1 = true; $__currentLoopData = $ppdbTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="px-5 py-3.5 flex items-center justify-between">
                    <div>
                        <p class="text-sm font-medium" style="color: var(--siakad-dark);"><?php echo e($p->nama_lengkap); ?></p>
                        <p class="text-xs" style="color: var(--siakad-secondary);">
                            <?php echo e($p->nomor_daftar); ?> · <?php echo e($p->created_at->diffForHumans()); ?>

                        </p>
                    </div>
                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                <?php if($p->status === 'menunggu'): ?>   bg-yellow-100 text-yellow-700
                <?php elseif($p->status === 'verifikasi'): ?> bg-blue-100 text-blue-700
                <?php elseif($p->status === 'diterima'): ?>   bg-green-100 text-green-700
                <?php else: ?> bg-red-100 text-red-700 <?php endif; ?>">
                        <?php echo e(ucfirst($p->status)); ?>

                    </span>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="px-5 py-10 text-center text-sm" style="color: var(--siakad-secondary);">
                    Belum ada pendaftar
                </div>
                <?php endif; ?>
            </div>
        </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?><?php /**PATH D:\HDD\Proyek\siak-pondok - Copy - Copy\resources\views/dashboards/admin.blade.php ENDPATH**/ ?>