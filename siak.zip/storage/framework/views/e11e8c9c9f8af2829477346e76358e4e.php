


<?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'layouts.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> Administrator Sistem <?php $__env->endSlot(); ?>

    <div class="mb-8">
        <h1 class="text-2xl font-semibold hidden md:block" style="color: var(--siakad-dark);">
            Sistem Administrator ⚙️
        </h1>
        <p class="text-sm mt-1 hidden md:block" style="color: var(--siakad-secondary);">
            Monitor aktivitas sistem dan manajemen akun pengguna
        </p>
    </div>

    <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <?php $__currentLoopData = [
        ['value'=>$totalUsers, 'label'=>'Total User', 'sub'=>'terdaftar'],
        ['value'=>$activeUsers, 'label'=>'User Aktif', 'sub'=>'dapat login'],
        ['value'=>$totalLogs, 'label'=>'Aktivitas Hari Ini','sub'=>'log tercatat'],
        ['value'=>$totalAiChats, 'label'=>'AI Chat Hari Ini', 'sub'=>'percakapan'],
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card-saas p-5">
            <p class="text-2xl font-bold" style="color: var(--siakad-dark);"><?php echo e($s['value']); ?></p>
            <p class="text-xs font-medium mt-0.5" style="color: var(--siakad-secondary);"><?php echo e($s['label']); ?></p>
            <p class="text-[11px] mt-0.5 text-gray-400"><?php echo e($s['sub']); ?></p>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="card-saas overflow-hidden">
        <div class="px-5 py-4 flex items-center justify-between"
            style="border-bottom: 1px solid var(--border-color);">
            <h3 class="font-semibold text-sm" style="color: var(--siakad-dark);">Aktivitas Sistem Hari Ini</h3>
            <a href="<?php echo e(route('sysadmin.activity-log')); ?>" class="text-xs font-medium"
                style="color: var(--siakad-primary);">Lihat semua →</a>
        </div>
        <div class="divide-y" style="border-color: var(--border-color);">
            <?php $__empty_1 = true; $__currentLoopData = $logsHariIni; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="px-5 py-3 flex items-center gap-3">
                <div class="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold
                        text-white flex-shrink-0"
                    style="background-color: var(--siakad-primary);">
                    <?php echo e(strtoupper(substr($log->user?->name ?? 'S', 0, 1))); ?>

                </div>
                <div class="flex-1 min-w-0">
                    <p class="text-sm" style="color: var(--siakad-dark);">
                        <span class="font-medium"><?php echo e($log->user?->name ?? 'System'); ?></span>
                        <span style="color: var(--siakad-secondary);"> · <?php echo e($log->action); ?></span>
                    </p>
                    <p class="text-xs text-gray-400">
                        <?php echo e($log->created_at->format('H:i:s')); ?> · <?php echo e($log->ip_address); ?>

                    </p>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="px-5 py-10 text-center text-sm" style="color: var(--siakad-secondary);">
                Belum ada aktivitas hari ini
            </div>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?><?php /**PATH D:\HDD\Proyek\siak-pondok - Copy - Copy\resources\views/dashboards/sysadmin.blade.php ENDPATH**/ ?>