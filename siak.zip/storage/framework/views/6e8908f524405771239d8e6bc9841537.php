



<?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'layouts.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> Penugasan Mengajar <?php $__env->endSlot(); ?>

    <div class="mb-6">
        <h2 class="text-xl font-semibold text-siakad-dark">Penugasan Mengajar</h2>
        <p class="text-sm text-siakad-secondary mt-0.5">
            Pilih guru, lalu tentukan mata pelajaran dan kelas yang diampunya
            <?php if($ta): ?> &middot; Tahun Ajaran <?php echo e($ta->nama); ?> (<?php echo e(ucfirst($ta->semester)); ?>) <?php endif; ?>
        </p>
    </div>

    <?php if(!$ta): ?>
    <div class="p-4 mb-6 rounded-xl text-sm" style="background:#fef3c7; border:1px solid #fde68a; color:#92400e;">
        Belum ada tahun ajaran aktif. Aktifkan salah satu tahun ajaran terlebih dahulu di Data Master.
    </div>
    <?php endif; ?>

    
    <div class="card-saas p-4 mb-6">
        <form method="GET" class="flex flex-wrap gap-3">
            <div class="relative flex-1 min-w-[200px]">
                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0" />
                    </svg>
                </div>
                <input type="text" name="search" value="<?php echo e(request('search')); ?>"
                    placeholder="Cari nama guru..."
                    class="block w-full pl-9 pr-4 py-2.5 text-sm rounded-xl border
                          border-gray-200 bg-gray-50
                          text-siakad-dark placeholder-gray-400
                          focus:ring-2 outline-none transition">
            </div>
            <button type="submit"
                class="px-4 py-2.5 text-sm font-semibold rounded-xl text-white transition-all"
                style="background-color: var(--siakad-primary);">
                Cari
            </button>
        </form>
    </div>

    <div class="card-saas overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-sm table-saas">
                <thead style="background-color: rgba(35,76,106,0.04);">
                    <tr>
                        <?php $__currentLoopData = ['Nama Guru','Email','Jumlah Penugasan','']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th class="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wide
                                   text-siakad-secondary whitespace-nowrap"><?php echo e($h); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </thead>
                <tbody class="divide-y" style="border-color: var(--border-color);">
                    <?php $__empty_1 = true; $__currentLoopData = $guruList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guru): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="px-5 py-3.5">
                            <div class="flex items-center gap-3">
                                <div class="w-8 h-8 rounded-xl flex items-center justify-center text-xs font-bold
                                    text-white flex-shrink-0" style="background-color: var(--siakad-primary);">
                                    <?php echo e(strtoupper(substr($guru->name, 0, 1))); ?>

                                </div>
                                <span class="font-medium text-siakad-dark"><?php echo e($guru->name); ?></span>
                            </div>
                        </td>
                        <td class="px-5 py-3.5 text-siakad-secondary text-xs"><?php echo e($guru->email); ?></td>
                        <td class="px-5 py-3.5">
                            <span class="px-2.5 py-0.5 rounded-full text-xs font-semibold
                                <?php echo e($guru->jumlah_penugasan > 0 ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'); ?>">
                                <?php echo e($guru->jumlah_penugasan); ?> penugasan
                            </span>
                        </td>
                        <td class="px-5 py-3.5 text-right">
                            <a href="<?php echo e(route('kurikulum.penugasan.show', $guru)); ?>"
                                class="text-xs font-semibold transition-colors" style="color: var(--siakad-primary);">
                                Atur Penugasan →
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" class="px-5 py-12 text-center text-sm text-siakad-secondary">
                            Tidak ada data guru
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if($guruList->hasPages()): ?>
        <div class="px-5 py-4" style="border-top: 1px solid var(--border-color);">
            <?php echo e($guruList->links()); ?>

        </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php /**PATH D:\HDD\Proyek\siak-pondok - Copy - Copy\resources\views/penugasan/index.blade.php ENDPATH**/ ?>