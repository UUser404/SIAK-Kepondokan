


<?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'layouts.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> Dashboard Kurikulum <?php $__env->endSlot(); ?>

    <div class="mb-8">
        <h1 class="text-2xl font-semibold hidden md:block" style="color: var(--siakad-dark);">
            Dashboard Kurikulum 📚
        </h1>
        <p class="text-sm mt-1 hidden md:block" style="color: var(--siakad-secondary);">
            Kelola kelas, jadwal, dan penilaian akademik santri
        </p>
    </div>

    <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <?php $__currentLoopData = [
        ['value'=>$totalKelas, 'label'=>'Total Kelas'],
        ['value'=>$totalSantri, 'label'=>'Total Santri'],
        ['value'=>$kelasBelumNilai, 'label'=>'Kelas Belum Nilai'],
        ['value'=>$pertemuanHariIni, 'label'=>'Pertemuan Hari Ini'],
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card-saas p-5">
            <p class="text-2xl font-bold" style="color: var(--siakad-dark);"><?php echo e($s['value']); ?></p>
            <p class="text-xs mt-0.5" style="color: var(--siakad-secondary);"><?php echo e($s['label']); ?></p>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="card-saas overflow-hidden">
        <div class="px-5 py-4 flex items-center justify-between"
            style="border-bottom: 1px solid var(--border-color);">
            <h3 class="font-semibold text-sm" style="color: var(--siakad-dark);">Daftar Kelas Aktif</h3>
            <a href="<?php echo e(route('kurikulum.kelas.index')); ?>" class="text-xs font-medium"
                style="color: var(--siakad-primary);">Kelola kelas →</a>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-sm table-saas">
                <thead style="background-color: rgba(35,76,106,0.04);">
                    <tr>
                        <?php $__currentLoopData = ['Kelas','Tingkatan','Wali Kelas','Santri']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th class="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wide"
                            style="color: var(--siakad-secondary);"><?php echo e($h); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </thead>
                <tbody class="divide-y" style="border-color: var(--border-color);">
                    <?php $__empty_1 = true; $__currentLoopData = $rekapKelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="px-5 py-3 font-medium" style="color: var(--siakad-dark);"><?php echo e($kelas->nama); ?></td>
                        <td class="px-5 py-3" style="color: var(--siakad-secondary);"><?php echo e($kelas->tingkatan->nama); ?></td>
                        <td class="px-5 py-3" style="color: var(--siakad-secondary);"><?php echo e($kelas->waliKelas?->name ?? '-'); ?></td>
                        <td class="px-5 py-3 font-semibold" style="color: var(--siakad-dark);"><?php echo e($kelas->jumlah_santri); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" class="px-5 py-10 text-center text-sm"
                            style="color: var(--siakad-secondary);">Belum ada kelas</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?><?php /**PATH D:\HDD\Proyek\siak-pondok - Copy - Copy\resources\views/dashboards/kurikulum.blade.php ENDPATH**/ ?>