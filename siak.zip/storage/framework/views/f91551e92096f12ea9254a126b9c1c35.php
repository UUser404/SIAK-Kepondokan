


<?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'layouts.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> Detail Nilai <?php $__env->endSlot(); ?>

    <div class="mb-6 flex items-center gap-3">
        <a href="<?php echo e(route('kurikulum.nilai.index')); ?>"
            class="p-2 rounded-xl border border-gray-200
              text-siakad-secondary
              hover:bg-gray-50 transition">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
            </svg>
        </a>
        <h2 class="text-xl font-semibold text-siakad-dark">Detail Nilai</h2>
    </div>

    
    <div class="card-saas p-4 mb-6">
        <form method="GET" class="flex flex-wrap gap-3 items-end">
            <div>
                <label class="block text-xs text-siakad-secondary mb-1">Kelas</label>
                <select name="kelas_id" onchange="this.form.submit()"
                    class="px-3 py-2.5 text-sm rounded-xl border border-gray-200
                           bg-gray-50 text-siakad-dark
                           focus:ring-2 outline-none transition">
                    <?php $__currentLoopData = $kelasList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($k->id); ?>" <?php if($kelas?->id == $k->id): echo 'selected'; endif; ?>>
                        <?php echo e($k->nama); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <label class="block text-xs text-siakad-secondary mb-1">Mata Pelajaran</label>
                <select name="mapel_id" onchange="this.form.submit()"
                    class="px-3 py-2.5 text-sm rounded-xl border border-gray-200
                           bg-gray-50 text-siakad-dark
                           focus:ring-2 outline-none transition">
                    <?php $__currentLoopData = $mapelList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($m->id); ?>" <?php if($mataPelajaran?->id == $m->id): echo 'selected'; endif; ?>>
                        <?php echo e($m->nama); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </form>
    </div>

    <?php if($rekap && $statistik): ?>

    
    <div class="grid grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
        <?php $__currentLoopData = [
        ['Rata-rata', $statistik['rata_rata'], ''],
        ['Tertinggi', $statistik['tertinggi'], ''],
        ['Terendah', $statistik['terendah'], ''],
        ['Tuntas', $statistik['jumlah_tuntas'], ''],
        ['% Tuntas', $statistik['persen_tuntas'].'%',''],
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $value]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card-saas p-4 text-center">
            <p class="text-xl font-bold text-siakad-dark"><?php echo e($value); ?></p>
            <p class="text-xs text-siakad-secondary mt-0.5"><?php echo e($label); ?></p>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <div class="card-saas p-5 mb-6">
        <p class="text-xs font-semibold text-siakad-secondary uppercase tracking-wide mb-4">
            Distribusi Predikat
        </p>
        <div class="grid grid-cols-4 gap-3">
            <?php $__currentLoopData = ['A'=>'green','B'=>'blue','C'=>'yellow','D'=>'red']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $predikat => $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $count = $statistik['distribusi'][$predikat] ?? 0; ?>
            <div class="text-center p-3 rounded-xl bg-<?php echo e($color); ?>-50 $color }}-900/20
                    border border-<?php echo e($color); ?>-100 $color }}-800">
                <p class="text-2xl font-bold text-<?php echo e($color); ?>-600 $color }}-400">
                    <?php echo e($count); ?>

                </p>
                <p class="text-xs font-semibold text-<?php echo e($color); ?>-700 $color }}-300 mt-0.5">
                    Predikat <?php echo e($predikat); ?>

                </p>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    
    <div class="mb-6">
        <form method="POST" action="<?php echo e(route('kurikulum.nilai.finalize')); ?>" class="inline">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="kelas_id" value="<?php echo e($kelas->id); ?>">
            <input type="hidden" name="mata_pelajaran_id" value="<?php echo e($mataPelajaran->id); ?>">
            <button type="submit"
                class="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold rounded-xl
                       text-white transition-all hover:-translate-y-0.5 hover:shadow-lg"
                style="background-color: var(--siakad-primary);"
                onmouseover="this.style.backgroundColor='var(--siakad-dark)'"
                onmouseout="this.style.backgroundColor='var(--siakad-primary)'"
                onclick="return confirm('Kalkulasi ulang nilai akhir semua santri di kelas ini?')">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0
                         0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
                Kalkulasi Nilai Akhir
            </button>
        </form>

        
        <a href="<?php echo e(route('kurikulum.nilai.export', ['kelas_id' => $kelas->id, 'mapel_id' => $mataPelajaran->id])); ?>"
            class="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold rounded-xl
                   border border-gray-200 text-siakad-dark hover:bg-gray-50 transition-all">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
            </svg>
            Export Nilai
        </a>
        <a href="<?php echo e(route('kurikulum.presensi.export', ['kelas_id' => $kelas->id, 'mapel_id' => $mataPelajaran->id])); ?>"
            class="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold rounded-xl
                   border border-gray-200 text-siakad-dark hover:bg-gray-50 transition-all">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
            </svg>
            Export Presensi
        </a>
    </div>

    
    <div class="card-saas overflow-hidden">
        <div class="px-5 py-3.5 flex items-center gap-2"
            style="border-bottom: 1px solid var(--border-color);
                background-color: rgba(35,76,106,0.04);">
            <div class="w-1 h-4 rounded-full" style="background-color: var(--siakad-primary);"></div>
            <h3 class="font-semibold text-sm text-siakad-dark">
                <?php echo e($kelas->nama); ?> — <?php echo e($mataPelajaran->nama); ?>

            </h3>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-sm table-saas">
                <thead style="background-color: rgba(35,76,106,0.04);">
                    <tr>
                        <th class="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wide
                               text-siakad-secondary sticky left-0 z-10"
                            style="background-color: rgba(35,76,106,0.04);">Santri</th>
                        <?php $__currentLoopData = $rekap['komponen']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th class="px-3 py-3 text-center text-xs font-semibold uppercase tracking-wide
                               text-siakad-secondary min-w-[70px]">
                            <?php echo e($k->kode); ?>

                        </th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <th class="px-3 py-3 text-center text-xs font-semibold uppercase tracking-wide
                               min-w-[80px]" style="color: var(--siakad-primary);">Akhir</th>
                        <th class="px-3 py-3 text-center text-xs font-semibold uppercase tracking-wide
                               text-siakad-secondary">Status</th>
                    </tr>
                </thead>
                <tbody class="divide-y" style="border-color: var(--border-color);">
                    <?php $__currentLoopData = $rekap['rows']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $na = $row['nilai_akhir']; ?>
                    <tr class="dark:hover:bg-gray-700/30">
                        <td class="px-5 py-3 sticky left-0 bg-white z-10">
                            <p class="font-medium text-siakad-dark text-xs">
                                <?php echo e($row['santri']->nama_lengkap); ?>

                            </p>
                        </td>
                        <?php $__currentLoopData = $rekap['komponen']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td class="px-3 py-3 text-center text-siakad-dark">
                            <?php echo e($row['komponen'][$k->kode] !== null
                           ? number_format($row['komponen'][$k->kode], 1)
                           : '—'); ?>

                        </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td class="px-3 py-3 text-center font-bold">
                            <?php if($na): ?>
                            <span class="<?php echo e($na->tuntas
                            ? 'text-green-600'
                            : 'text-red-600'); ?>">
                                <?php echo e($na->nilai_akhir); ?>

                            </span>
                            <?php else: ?>
                            <span class="text-gray-300">—</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-3 py-3 text-center">
                            <?php if($na): ?>
                            <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold
                            <?php echo e($na->tuntas
                               ? 'bg-green-100 text-green-700'
                               : 'bg-red-100 text-red-700'); ?>">
                                <?php echo e($na->predikat); ?> · <?php echo e($na->tuntas ? 'Tuntas' : 'Belum'); ?>

                            </span>
                            <?php else: ?>
                            <span class="text-gray-300 text-xs">Belum diisi</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?><?php /**PATH D:\HDD\Proyek\siak-pondok - Copy - Copy\resources\views/nilai/kurikulum-show.blade.php ENDPATH**/ ?>