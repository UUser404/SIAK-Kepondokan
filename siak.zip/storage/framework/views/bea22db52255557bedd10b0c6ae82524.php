


<?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'layouts.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> Penilaian <?php $__env->endSlot(); ?>

    <div class="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
            <h2 class="text-xl font-semibold text-siakad-dark">Penilaian</h2>
            <p class="text-sm text-siakad-secondary mt-0.5">
                Monitor progress input nilai seluruh kelas
            </p>
        </div>
        <?php if($ta): ?>
        <span class="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl text-sm font-medium border"
            style="background-color: rgba(35,76,106,0.08);
                 color: var(--siakad-primary);
                 border-color: rgba(35,76,106,0.2);">
            <?php echo e($ta->nama_lengkap); ?>

        </span>
        <?php endif; ?>
    </div>

    
    <div class="grid grid-cols-3 gap-4 mb-8">
        <?php $__currentLoopData = [
        ['Total Kelas', $kelasList->count()],
        ['Total Mapel', $mapelList->count()],
        ['Sudah Final', collect($progressMap)->where('persen', 100)->count()],
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $value]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card-saas p-5 text-center">
            <p class="text-2xl font-bold text-siakad-dark"><?php echo e($value); ?></p>
            <p class="text-xs text-siakad-secondary mt-0.5"><?php echo e($label); ?></p>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        <?php $__empty_1 = true; $__currentLoopData = $kelasList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php $prog = $progressMap[$kelas->id] ?? ['sudah'=>0,'total'=>0,'persen'=>0]; ?>
        <div class="card-saas p-5 hover:border-siakad-primary/30
                transition">
            <div class="flex items-start justify-between mb-3">
                <div>
                    <p class="font-semibold text-siakad-dark"><?php echo e($kelas->nama); ?></p>
                    <p class="text-xs text-siakad-secondary mt-0.5">
                        <?php echo e($kelas->tingkatan->nama); ?> ·
                        <?php echo e($kelas->jumlah_santri); ?> santri
                    </p>
                    <p class="text-xs text-siakad-secondary">
                        Wali: <?php echo e($kelas->waliKelas?->name ?? '-'); ?>

                    </p>
                </div>
                <?php if($prog['persen'] === 100): ?>
                <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold
                         bg-green-100 text-green-700 flex-shrink-0">
                    Lengkap
                </span>
                <?php endif; ?>
            </div>

            <div class="mb-4">
                <div class="flex justify-between text-xs mb-1.5">
                    <span class="text-siakad-secondary">Progress nilai akhir</span>
                    <span class="font-semibold text-siakad-dark"><?php echo e($prog['persen']); ?>%</span>
                </div>
                <div class="w-full bg-gray-100 rounded-full h-2">
                    <div class="h-2 rounded-full transition-all"
                        style="width: <?php echo e($prog['persen']); ?>%;
                            background-color: <?php echo e($prog['persen'] === 100 ? '#16a34a' : 'var(--siakad-primary)'); ?>">
                    </div>
                </div>
            </div>

            <a href="<?php echo e(route('kurikulum.nilai.show', ['kelas_id'=>$kelas->id])); ?>"
                class="block w-full text-center py-2 text-xs font-semibold rounded-xl
                  border transition hover:-translate-y-0.5"
                style="border-color: var(--siakad-primary); color: var(--siakad-primary);"
                onmouseover="this.style.backgroundColor='rgba(35,76,106,0.08)'"
                onmouseout="this.style.backgroundColor='transparent'">
                Lihat Detail Nilai
            </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-span-3 card-saas p-12 text-center">
            <p class="text-siakad-secondary text-sm">
                Belum ada kelas aktif
            </p>
        </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?><?php /**PATH D:\HDD\Proyek\siak-pondok - Copy - Copy\resources\views/nilai/kurikulum-index.blade.php ENDPATH**/ ?>