



<?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'layouts.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> Pendaftar PPDB <?php $__env->endSlot(); ?>

    <div class="mb-6 flex items-center gap-3">
        <a href="<?php echo e(route('admin.ppdb.index')); ?>"
            class="p-2 rounded-xl border border-gray-200
              text-siakad-secondary
              hover:bg-gray-50 transition">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
            </svg>
        </a>
        <div>
            <h2 class="text-xl font-semibold text-siakad-dark">
                <?php echo e($periodeAktif?->nama ?? 'Pendaftar PPDB'); ?>

            </h2>
            <?php if($periodeAktif): ?>
            <p class="text-sm text-siakad-secondary mt-0.5">
                <?php echo e($periodeAktif->tanggal_buka->format('d M Y')); ?> —
                <?php echo e($periodeAktif->tanggal_tutup->format('d M Y')); ?> ·
                Sisa kuota: <?php echo e($stats['sisa_kuota']); ?>

            </p>
            <?php endif; ?>
        </div>
    </div>

    <?php if($periodeAktif && $stats): ?>
    
    <div class="grid grid-cols-2 lg:grid-cols-5 gap-3 mb-6">
        <?php $__currentLoopData = [
        ['Total', $stats['total'], 'blue'],
        ['Menunggu', $stats['menunggu'], 'yellow'],
        ['Verifikasi', $stats['verifikasi'], 'purple'],
        ['Diterima', $stats['diterima'], 'green'],
        ['Ditolak', $stats['ditolak'], 'red'],
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$lbl, $val, $c]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card-saas p-4 text-center">
            <p class="text-xl font-bold text-<?php echo e($c); ?>-600 $c }}-400"><?php echo e($val); ?></p>
            <p class="text-xs text-siakad-secondary mt-0.5"><?php echo e($lbl); ?></p>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>

    
    <div class="card-saas p-4 mb-6">
        <form method="GET" class="flex flex-wrap gap-3">
            <div class="relative flex-1 min-w-[180px]">
                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0" />
                    </svg>
                </div>
                <input type="text" name="search" value="<?php echo e(request('search')); ?>"
                    placeholder="Cari nama / nomor daftar..."
                    class="block w-full pl-9 pr-4 py-2.5 text-sm rounded-xl border
                          border-gray-200 bg-gray-50
                          text-siakad-dark placeholder-gray-400
                          focus:ring-2 outline-none transition">
            </div>
            <select name="status" onchange="this.form.submit()"
                class="px-3 py-2.5 text-sm rounded-xl border border-gray-200
                       bg-gray-50 text-siakad-dark
                       focus:ring-2 outline-none transition">
                <option value="">Semua Status</option>
                <?php $__currentLoopData = ['menunggu','verifikasi','diterima','ditolak']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($s); ?>" <?php if(request('status')===$s): echo 'selected'; endif; ?>><?php echo e(ucfirst($s)); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <button type="submit"
                class="px-4 py-2.5 text-sm font-medium rounded-xl text-white"
                style="background-color: var(--siakad-primary);">Cari</button>
        </form>
    </div>

    
    <div class="card-saas overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-sm table-saas">
                <thead style="background-color: rgba(35,76,106,0.04);">
                    <tr>
                        <?php $__currentLoopData = ['No. Daftar','Nama','L/P','Asal Sekolah','No. HP Wali','Daftar','Status','Aksi']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th class="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wide
                               text-siakad-secondary whitespace-nowrap"><?php echo e($h); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </thead>
                <tbody class="divide-y" style="border-color: var(--border-color);">
                    <?php $__empty_1 = true; $__currentLoopData = $pendaftar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="dark:hover:bg-gray-700/30">
                        <td class="px-5 py-3.5 font-mono text-xs font-semibold"
                            style="color: var(--siakad-primary);">
                            <?php echo e($p->nomor_daftar); ?>

                        </td>
                        <td class="px-5 py-3.5">
                            <p class="font-medium text-siakad-dark"><?php echo e($p->nama_lengkap); ?></p>
                            <p class="text-xs text-siakad-secondary">
                                <?php echo e($p->tempat_lahir); ?>, <?php echo e($p->tanggal_lahir?->format('d/m/Y')); ?>

                            </p>
                        </td>
                        <td class="px-5 py-3.5">
                            <span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium
                            <?php echo e($p->jenis_kelamin === 'L'
                               ? 'bg-blue-100 text-blue-700'
                               : 'bg-pink-100 text-pink-700'); ?>">
                                <?php echo e($p->jenis_kelamin === 'L' ? 'L' : 'P'); ?>

                            </span>
                        </td>
                        <td class="px-5 py-3.5 text-siakad-secondary text-xs">
                            <?php echo e($p->asal_sekolah ?? '—'); ?>

                        </td>
                        <td class="px-5 py-3.5 text-siakad-secondary text-xs">
                            <?php echo e($p->no_hp_wali); ?>

                        </td>
                        <td class="px-5 py-3.5 text-xs text-siakad-secondary whitespace-nowrap">
                            <?php echo e($p->created_at->locale('id')->isoFormat('D MMM Y')); ?>

                        </td>
                        <td class="px-5 py-3.5">
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold
                            <?php if($p->status === 'menunggu'): ?>    bg-yellow-100 text-yellow-700
                            <?php elseif($p->status === 'verifikasi'): ?> bg-purple-100 text-purple-700
                            <?php elseif($p->status === 'diterima'): ?>   bg-green-100 text-green-700
                            <?php else: ?> bg-red-100 text-red-700 <?php endif; ?>">
                                <?php echo e(ucfirst($p->status)); ?>

                            </span>
                        </td>
                        <td class="px-5 py-3.5">
                            <div class="flex items-center gap-1.5">
                                <a href="<?php echo e(route('admin.ppdb.detail', $p)); ?>"
                                    class="px-2.5 py-1 text-xs font-medium rounded-lg border transition
                                      hover:bg-siakad-primary/5"
                                    style="border-color: var(--siakad-primary); color: var(--siakad-primary);">
                                    Detail
                                </a>
                                <?php if($p->status === 'menunggu'): ?>
                                <form method="POST" action="<?php echo e(route('admin.ppdb.verifikasi', $p)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit"
                                        class="px-2.5 py-1 text-xs font-medium rounded-lg
                                               bg-purple-100 text-purple-700 hover:bg-purple-200
                                               transition">
                                        Verifikasi
                                    </button>
                                </form>
                                <?php endif; ?>
                                <?php if(in_array($p->status, ['menunggu','verifikasi'])): ?>
                                <form method="POST" action="<?php echo e(route('admin.ppdb.terima', $p)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit"
                                        class="px-2.5 py-1 text-xs font-medium rounded-lg
                                               bg-green-100 text-green-700 hover:bg-green-200
                                               transition">
                                        Terima
                                    </button>
                                </form>
                                <?php endif; ?>
                                <?php if($p->status === 'diterima' && !$p->santri_id): ?>
                                <form method="POST" action="<?php echo e(route('admin.ppdb.konversi', $p)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit"
                                        onclick="return confirm('Konversi ke data santri?')"
                                        class="px-2.5 py-1 text-xs font-semibold rounded-lg
                                               text-white transition"
                                        style="background-color: var(--siakad-primary);">
                                        Konversi
                                    </button>
                                </form>
                                <?php elseif($p->santri_id): ?>
                                <a href="<?php echo e(route('admin.santri.show', $p->santri_id)); ?>"
                                    class="px-2.5 py-1 text-xs font-medium rounded-lg
                                      bg-blue-100 text-blue-700 hover:bg-blue-200 transition">
                                    Lihat Santri
                                </a>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="px-5 py-12 text-center text-sm
                                           text-siakad-secondary">
                            Belum ada pendaftar
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if($pendaftar->hasPages()): ?>
        <div class="px-5 py-4" style="border-top: 1px solid var(--border-color);">
            <?php echo e($pendaftar->links()); ?>

        </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?><?php /**PATH D:\HDD\Proyek\siak-pondok - Copy - Copy\resources\views/ppdb/pendaftar.blade.php ENDPATH**/ ?>