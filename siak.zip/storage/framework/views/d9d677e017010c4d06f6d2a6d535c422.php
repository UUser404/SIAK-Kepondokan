




<?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'layouts.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> Penugasan Mengajar <?php $__env->endSlot(); ?>

    <div class="mb-6 flex items-center gap-3">
        <a href="<?php echo e(route('kurikulum.penugasan.index')); ?>"
            class="p-2 rounded-xl border border-gray-200
              text-siakad-secondary hover:bg-gray-50 transition">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
            </svg>
        </a>
        <div>
            <h2 class="text-xl font-semibold text-siakad-dark"><?php echo e($guru->name); ?></h2>
            <p class="text-sm text-siakad-secondary mt-0.5">
                <?php echo e($guru->email); ?>

                <?php if($ta): ?> &middot; Tahun Ajaran <?php echo e($ta->nama); ?> (<?php echo e(ucfirst($ta->semester)); ?>) <?php endif; ?>
            </p>
        </div>
    </div>

    <?php if(!$ta): ?>
    <div class="p-4 mb-6 rounded-xl text-sm" style="background:#fef3c7; border:1px solid #fde68a; color:#92400e;">
        Belum ada tahun ajaran aktif. Aktifkan salah satu tahun ajaran terlebih dahulu di Data Master.
    </div>
    <?php endif; ?>

    <div class="grid lg:grid-cols-3 gap-5">

        
        <div class="lg:col-span-2 space-y-4">
            <?php $__empty_1 = true; $__currentLoopData = $penugasanList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mapelId => $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php $mapel = $rows->first()->mataPelajaran; ?>
            <div class="card-saas overflow-hidden">
                <div class="px-5 py-3.5 flex items-center gap-2"
                    style="border-bottom: 1px solid var(--border-color);
                            background-color: rgba(35,76,106,0.04);">
                    <div class="w-1 h-4 rounded-full bg-blue-500"></div>
                    <h3 class="font-semibold text-sm text-siakad-dark"><?php echo e($mapel->nama); ?></h3>
                    <span class="text-xs text-siakad-secondary">(<?php echo e($rows->count()); ?> kelas)</span>
                </div>
                <div class="p-4 flex flex-wrap gap-2">
                    <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="inline-flex items-center gap-2 pl-3 pr-1.5 py-1.5 rounded-xl text-xs font-medium
                                 bg-gray-100 text-siakad-dark">
                        <?php echo e($p->kelas->nama); ?>

                        <form method="POST" action="<?php echo e(route('kurikulum.penugasan.destroy', $p)); ?>"
                            onsubmit="return confirm('Hapus penugasan <?php echo e($mapel->nama); ?> - <?php echo e($p->kelas->nama); ?>?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit"
                                class="w-5 h-5 rounded-full flex items-center justify-center
                                       text-gray-400 hover:bg-red-100 hover:text-red-600 transition">
                                <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M6 18L18 6M6 6l12 12" />
                                </svg>
                            </button>
                        </form>
                    </span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="card-saas p-10 text-center">
                <svg class="w-10 h-10 mx-auto mb-3 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
                        d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                <p class="text-sm text-siakad-secondary">
                    Guru ini belum memiliki penugasan mengajar. Tambahkan lewat form di samping.
                </p>
            </div>
            <?php endif; ?>
        </div>

        
        <div>
            <div class="card-saas p-5 sticky top-24">
                <div class="flex items-center gap-2 mb-4">
                    <div class="w-1 h-4 rounded-full" style="background-color: var(--siakad-primary);"></div>
                    <h3 class="font-semibold text-sm text-siakad-dark">Tambah Mapel & Kelas</h3>
                </div>

                <?php if($errors->any()): ?>
                <div class="px-3 py-2.5 rounded-xl text-xs mb-4"
                    style="background: #fef2f2; border: 1px solid #fecaca; color: #dc2626;">
                    <ul class="list-disc list-inside space-y-0.5">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('kurikulum.penugasan.store', $guru)); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="mb-4">
                        <label class="block text-sm font-medium text-siakad-dark mb-1.5">
                            Mata Pelajaran <span class="text-red-500">*</span>
                        </label>
                        <select name="mata_pelajaran_id" required
                            class="w-full px-3.5 py-2.5 text-sm rounded-xl border border-gray-200
                                   bg-gray-50 text-siakad-dark focus:ring-2 outline-none transition">
                            <option value="">-- Pilih Mapel --</option>
                            <?php $__currentLoopData = $mapelList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($m->id); ?>" <?php if(old('mata_pelajaran_id') == $m->id): echo 'selected'; endif; ?>><?php echo e($m->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <p class="text-xs text-siakad-secondary mt-1.5">
                            Tambahkan satu mapel dulu, lalu ulangi form ini kalau guru mengampu mapel lain.
                        </p>
                    </div>

                    <div class="mb-4">
                        <label class="block text-sm font-medium text-siakad-dark mb-1.5">
                            Kelas yang Diampu <span class="text-red-500">*</span>
                        </label>
                        <div class="space-y-1.5 max-h-64 overflow-y-auto p-2 rounded-xl border border-gray-200 bg-gray-50">
                            <?php $__empty_1 = true; $__currentLoopData = $kelasList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <label class="flex items-center gap-2.5 px-2 py-1.5 rounded-lg hover:bg-white transition cursor-pointer">
                                <input type="checkbox" name="kelas_id[]" value="<?php echo e($k->id); ?>"
                                    <?php echo e(collect(old('kelas_id'))->contains($k->id) ? 'checked' : ''); ?>

                                    class="rounded border-gray-300 text-siakad-primary focus:ring-siakad-primary">
                                <span class="text-sm text-siakad-dark"><?php echo e($k->nama); ?></span>
                            </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-xs text-siakad-secondary px-2 py-1.5">Belum ada data kelas.</p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <button type="submit" <?php echo e((!$ta || $kelasList->isEmpty()) ? 'disabled' : ''); ?>

                        class="w-full px-4 py-2.5 text-sm font-semibold rounded-xl text-white transition-all
                                   hover:-translate-y-0.5 hover:shadow-lg disabled:opacity-50 disabled:pointer-events-none"
                        style="background-color: var(--siakad-primary);"
                        onmouseover="this.style.backgroundColor='var(--siakad-dark)'"
                        onmouseout="this.style.backgroundColor='var(--siakad-primary)'">
                        Simpan Penugasan
                    </button>
                </form>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php /**PATH D:\HDD\Proyek\siak-pondok - Copy - Copy\resources\views/penugasan/show.blade.php ENDPATH**/ ?>