<?php

namespace App\Http\Controllers\Admin;

use App\Exports\SantriExport;
use App\Http\Controllers\Controller;
use App\Models\Kelas;
use App\Models\Santri;
use App\Models\TahunAjaran;
use App\Services\ActivityLogService;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;

class SantriController extends Controller
{
    public function index(Request $request)
    {
        $query = Santri::query();

        if ($request->filled('search')) {
            $query->where(function ($q) use ($request) {
                $q->where('nama_lengkap', 'like', "%{$request->search}%")
                    ->orWhere('nis', 'like', "%{$request->search}%");
            });
        }

        // Perbaikan: view sudah punya dropdown filter "Kelas" dan "L/P" (jenis_kelamin),
        // tapi sebelumnya filter ini tidak pernah diterapkan ke query sama sekali,
        // dan $kelasList (buat isi dropdown-nya) juga tidak pernah dikirim ke view --
        // menyebabkan "Undefined variable $kelasList" saat halaman dibuka.
        if ($request->filled('kelas_id')) {
            $query->whereHas('santriKelas', function ($q) use ($request) {
                $q->where('kelas_id', $request->kelas_id)->where('status', 'aktif');
            });
        }

        if ($request->filled('jenis_kelamin')) {
            $query->where('jenis_kelamin', $request->jenis_kelamin);
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        $santri = $query->orderBy('nama_lengkap')->paginate(20)->withQueryString();

        $ta = TahunAjaran::aktif();
        $kelasList = Kelas::when($ta, fn($q) => $q->where('tahun_ajaran_id', $ta->id))
            ->orderBy('nama')->get();

        return view('santri.index', compact('santri', 'kelasList'));
    }

    public function create()
    {
        return view('santri.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'nis'           => ['required', 'string', 'unique:santri,nis'],
            'nisn'          => ['nullable', 'string', 'unique:santri,nisn'],
            'nama_lengkap'  => ['required', 'string', 'max:100'],
            'tempat_lahir'  => ['required', 'string', 'max:100'],
            'tanggal_lahir' => ['required', 'date'],
            'jenis_kelamin' => ['required', 'in:L,P'],
            'alamat'        => ['nullable', 'string'],
            'asal_sekolah'  => ['nullable', 'string', 'max:100'],
            'nama_ayah'     => ['nullable', 'string', 'max:100'],
            'nama_ibu'      => ['nullable', 'string', 'max:100'],
            'nama_wali'     => ['nullable', 'string', 'max:100'],
            'no_hp_wali'    => ['nullable', 'string', 'max:20'],
            'angkatan'      => ['required', 'integer'],
            'status'        => ['required', 'in:aktif,nonaktif,alumni'],
        ]);

        $santri = Santri::create($validated);
        ActivityLogService::logCreate($santri);

        return redirect()->route('admin.santri.show', $santri)
            ->with('success', 'Data santri berhasil ditambahkan.');
    }

    public function show(Santri $santri)
    {
        return view('santri.show', compact('santri'));
    }

    public function profil(Santri $santri)
    {
        return view('santri.profil', compact('santri'));
    }

    public function edit(Santri $santri)
    {
        return view('santri.edit', compact('santri'));
    }

    public function update(Request $request, Santri $santri)
    {
        $validated = $request->validate([
            'nis'           => ['required', 'string', 'unique:santri,nis,' . $santri->id],
            'nisn'          => ['nullable', 'string', 'unique:santri,nisn,' . $santri->id],
            'nama_lengkap'  => ['required', 'string', 'max:100'],
            'tempat_lahir'  => ['required', 'string', 'max:100'],
            'tanggal_lahir' => ['required', 'date'],
            'jenis_kelamin' => ['required', 'in:L,P'],
            'alamat'        => ['nullable', 'string'],
            'asal_sekolah'  => ['nullable', 'string', 'max:100'],
            'nama_ayah'     => ['nullable', 'string', 'max:100'],
            'nama_ibu'      => ['nullable', 'string', 'max:100'],
            'nama_wali'     => ['nullable', 'string', 'max:100'],
            'no_hp_wali'    => ['nullable', 'string', 'max:20'],
            'angkatan'      => ['required', 'integer'],
            'status'        => ['required', 'in:aktif,nonaktif,alumni'],
        ]);

        $santri->update($validated);
        ActivityLogService::logUpdate($santri);

        return redirect()->route('admin.santri.show', $santri)
            ->with('success', 'Data santri berhasil diperbarui.');
    }

    public function destroy(Santri $santri)
    {
        ActivityLogService::logDelete($santri);
        $santri->delete();

        return redirect()->route('admin.santri.index')
            ->with('success', 'Data santri berhasil dihapus.');
    }

    public function export(Request $request)
    {
        $filters = $request->only(['status', 'kelas_id']);

        return Excel::download(
            new SantriExport($filters),
            'data-santri-' . now()->format('Y-m-d_His') . '.xlsx'
        );
    }
}
